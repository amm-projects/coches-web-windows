# coches-web-windows

COMO EJECUTARLA:

Primera Forma (Con Apache)

  1. Tener apache instalado
  2. Mover la carpeta dentro de la carpeta de Apache (www)
  3. En la terminal ubicarse dentro del directorio del proyecto (coches-app) y escribir "npm run dev"
  4. En el navegador poner com URL: http://coches-app.test/ o https://coches-app.test/

Segunda Forma (Con Composer Run Dev)

  1. En el terminal ubicarse dentro del directorio del proyecto (coches-app) y escribir "composer run dev"
  2. En el navegador poner la url: http://localhost:8000
